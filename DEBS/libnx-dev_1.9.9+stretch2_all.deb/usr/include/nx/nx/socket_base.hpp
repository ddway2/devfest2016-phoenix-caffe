#ifndef __NX_SOCKET_BASE_H__
#define __NX_SOCKET_BASE_H__

namespace nx {

struct socket_base
{};

} // namespace nx

#endif // __NX_SOCKET_BASE_H__
