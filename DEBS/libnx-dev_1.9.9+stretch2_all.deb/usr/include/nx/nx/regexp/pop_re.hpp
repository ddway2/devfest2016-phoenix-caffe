// No header guard

#undef NX_RE
