// No header guard

#include <string>

#define NX_RE(NAME, RE) \
const std::string NAME = RE;
