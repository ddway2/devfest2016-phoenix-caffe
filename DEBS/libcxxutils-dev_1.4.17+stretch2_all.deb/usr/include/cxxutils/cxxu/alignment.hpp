// No header guard

#undef CXXU_ALIGNMENT
#define CXXU_ALIGNMENT 16
