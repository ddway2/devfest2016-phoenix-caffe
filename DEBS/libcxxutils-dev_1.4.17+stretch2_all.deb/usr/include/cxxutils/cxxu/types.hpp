#ifndef __CXXU_TYPES__
#define __CXXU_TYPES__

#include <string>
#include <vector>
#include <map>

namespace cxxu {

typedef std::vector<std::string> string_list;

} // namespace cxxu


#endif // __CXXU_TYPES__
