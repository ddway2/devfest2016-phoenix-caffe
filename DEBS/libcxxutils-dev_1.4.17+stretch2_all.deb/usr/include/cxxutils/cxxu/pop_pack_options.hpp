// No header guard

#ifdef WIN32
#undef CXXU_PACKED
#pragma pack(pop)
#endif

#ifdef UNIX
#undef CXXU_PACKED
#endif
